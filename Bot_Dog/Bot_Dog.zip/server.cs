//Base Blockhead guy
if(ForceRequiredAddOn("Bot_Hole") == $Error::None)
{
	exec("./Player_Dog.cs");
	exec("./bot_base.cs");
}