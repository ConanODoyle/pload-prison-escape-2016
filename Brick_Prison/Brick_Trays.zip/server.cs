datablock fxDTSBrickData(brickTrayData)
{
	brickFile = "./tray.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "Trays";
	iconName = "Add-Ons/Brick_Trays/tray";
};